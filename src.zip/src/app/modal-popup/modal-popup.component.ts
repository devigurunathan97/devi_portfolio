import { Component } from '@angular/core';

@Component({
  selector: 'app-modal-popup',
  standalone: true,
  imports: [],
  templateUrl: './modal-popup.component.html',
  styleUrl: './modal-popup.component.scss'
})
export class ModalPopupComponent {

}
